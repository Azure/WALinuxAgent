#!/usr/bin/env sh

exit $*